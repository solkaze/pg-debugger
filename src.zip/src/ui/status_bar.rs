use ratatui::{
    layout::{Constraint, Direction, Layout, Rect},
    style::{Color, Modifier, Style},
    widgets::{Block, Paragraph},
    Frame,
};

use crate::app::App;

pub fn render(f: &mut Frame, app: &App, area: Rect) {
    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Length(1), Constraint::Length(1)])
        .split(area);

    // 上段: 現在の停止位置（GDB からのイベントで更新される）
    let location_text = if !app.status_message.is_empty() {
        app.status_message.clone()
    } else {
        "GDB 未起動".to_string()
    };

    let location = Paragraph::new(location_text)
        .block(Block::default())
        .style(Style::default().fg(Color::Yellow).bg(Color::DarkGray));
    f.render_widget(location, chunks[0]);

    // 下段: キーバインド一覧
    let keys = " n/F10:Next  s/F11:Step  f/F12:Finish  c:Continue  b:Breakpoint  Tab:Focus  q:Quit";
    let keybinds = Paragraph::new(keys)
        .block(Block::default())
        .style(Style::default().fg(Color::Black).bg(Color::White).add_modifier(Modifier::BOLD));
    f.render_widget(keybinds, chunks[1]);
}
