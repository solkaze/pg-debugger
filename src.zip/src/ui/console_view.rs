use ratatui::{
    layout::Rect,
    style::{Color, Style},
    text::{Line, Span},
    widgets::{Block, Borders, Paragraph},
    Frame,
};

use crate::app::{App, Panel};

pub fn render(f: &mut Frame, app: &App, area: Rect) {
    let focused = app.focused_panel == Panel::Console;
    let border_style = if focused {
        Style::default().fg(Color::Yellow)
    } else {
        Style::default()
    };

    let block = Block::default()
        .title("Console")
        .borders(Borders::ALL)
        .border_style(border_style);

    if app.console_lines.is_empty() {
        let widget = Paragraph::new("(出力なし)").block(block);
        f.render_widget(widget, area);
        return;
    }

    let view_height = area.height.saturating_sub(2) as usize;
    // 最新行が下に表示されるよう末尾から view_height 行分を取る
    let skip = app.console_lines.len().saturating_sub(view_height);

    let lines: Vec<Line> = app
        .console_lines
        .iter()
        .skip(skip)
        .take(view_height)
        .map(|text| Line::from(Span::raw(text.clone())))
        .collect();

    let widget = Paragraph::new(lines).block(block);
    f.render_widget(widget, area);
}
