use ratatui::{
    layout::Rect,
    style::{Color, Modifier, Style},
    text::{Line, Span},
    widgets::{Block, Borders, Paragraph},
    Frame,
};

use crate::app::{App, Panel};

pub fn render(f: &mut Frame, app: &App, area: Rect) {
    let focused = app.focused_panel == Panel::Source;
    let border_style = if focused {
        Style::default().fg(Color::Yellow)
    } else {
        Style::default()
    };

    let title = match &app.current_file {
        Some(p) => format!("Source – {}", p.display()),
        None => "Source".to_string(),
    };

    let block = Block::default()
        .title(title)
        .borders(Borders::ALL)
        .border_style(border_style);

    if app.source_lines.is_empty() {
        let widget = Paragraph::new("(no file loaded)").block(block);
        f.render_widget(widget, area);
        return;
    }

    // 表示可能な高さ（ボーダー分を引く）
    let view_height = area.height.saturating_sub(2) as usize;

    // current_line は 1-origin
    let current_idx = app
        .current_line
        .map(|l| (l as usize).saturating_sub(1))
        .unwrap_or(0);

    // current_line が中央に来るようにオフセットを計算
    let scroll_offset = current_idx.saturating_sub(view_height / 2);

    let line_num_width = app.source_lines.len().to_string().len().max(2);

    let lines: Vec<Line> = app
        .source_lines
        .iter()
        .enumerate()
        .skip(scroll_offset)
        .take(view_height)
        .map(|(i, text)| {
            let line_num = i + 1;
            let num_span = Span::styled(
                format!("{:>width$} | ", line_num, width = line_num_width),
                Style::default().fg(Color::DarkGray),
            );
            if i == current_idx {
                Line::from(vec![
                    num_span,
                    Span::styled(
                        text.clone(),
                        Style::default()
                            .fg(Color::Yellow)
                            .add_modifier(Modifier::BOLD),
                    ),
                ])
            } else {
                Line::from(vec![num_span, Span::raw(text.clone())])
            }
        })
        .collect();

    let widget = Paragraph::new(lines).block(block);
    f.render_widget(widget, area);
}
