use anyhow::Result;
use crossterm::event::{KeyCode, KeyEvent};
use std::path::PathBuf;

use crate::debugger::gdb::{GdbBackend, GdbEvent};
use crate::debugger::Variable;

#[derive(Default, Clone, Copy, PartialEq)]
pub enum Panel {
    #[default]
    Source,
    Vars,
    Console,
}

pub struct App {
    pub focused_panel: Panel,
    /// GDB バックエンド（実行ファイルが指定された場合のみ Some）
    gdb: Option<GdbBackend>,
    /// 現在停止しているソースファイル
    pub current_file: Option<PathBuf>,
    /// 現在停止している行番号
    pub current_line: Option<u32>,
    /// ステータスバーに表示するメッセージ
    pub status_message: String,
    /// ソースファイルの行キャッシュ
    pub source_lines: Vec<String>,
    /// キャッシュ済みファイルパス（変更検知用）
    loaded_file: Option<PathBuf>,
    /// 現在ステップの変数一覧
    pub variables: Vec<Variable>,
    /// 1 ステップ前の変数一覧（変更検知用）
    pub prev_variables: Vec<Variable>,
    /// 変数ビューのスクロールオフセット
    pub var_scroll: usize,
    /// コンソール出力行（最大 500 行）
    pub console_lines: Vec<String>,
}

impl App {
    /// アプリケーションを初期化する。
    /// executable が Some の場合は GDB を起動して main の先頭で停止させる。
    pub async fn new(executable: Option<&str>) -> Result<Self> {
        let mut gdb = None;

        if let Some(exe) = executable {
            let backend = GdbBackend::new(std::path::Path::new(exe)).await?;
            backend.start()?;
            gdb = Some(backend);
        }

        Ok(Self {
            focused_panel: Panel::Source,
            gdb,
            current_file: None,
            current_line: None,
            status_message: "準備完了 – n: Next  s: Step  f: Finish  c: Continue  q: Quit".to_string(),
            source_lines: Vec::new(),
            loaded_file: None,
            variables: Vec::new(),
            prev_variables: Vec::new(),
            var_scroll: 0,
            console_lines: Vec::new(),
        })
    }

    /// キー入力を処理する
    pub fn handle_key(&mut self, key: KeyEvent) {
        match key.code {
            KeyCode::Tab => self.toggle_focus(),
            KeyCode::Char('n') | KeyCode::F(10) => self.send_next(),
            KeyCode::Char('c') | KeyCode::F(5) => self.send_continue(),
            KeyCode::Up => self.scroll_up(),
            KeyCode::Down => self.scroll_down(),
            _ => {}
        }
    }

    /// GDB イベントをポーリングし、App の状態を更新する
    /// メインループの各フレームで呼び出す
    pub fn poll_gdb_events(&mut self) {
        let Some(gdb) = &mut self.gdb else { return };

        while let Some(event) = gdb.try_recv_event() {
            match event {
                GdbEvent::Stopped { file, line } => {
                    self.status_message = format!("{}: {}行目", file.display(), line);
                    self.current_line = Some(line);
                    if self.loaded_file.as_deref() != Some(file.as_path()) {
                        tracing::info!("ソースファイル読み込み: {}", file.display());
                        match std::fs::read_to_string(&file) {
                            Ok(content) => {
                                self.source_lines = content.lines().map(|l| l.to_string()).collect();
                                self.loaded_file = Some(file.clone());
                                tracing::info!("読み込み完了: {} 行", self.source_lines.len());
                            }
                            Err(e) => {
                                tracing::error!("ファイル読み込み失敗 {}: {}", file.display(), e);
                                self.source_lines.clear();
                                self.loaded_file = None;
                            }
                        }
                    }
                    self.current_file = Some(file.clone());
                    gdb.update_location(file, line);
                    // 停止のたびに変数一覧を要求する
                    if let Err(e) = gdb.request_variables() {
                        tracing::error!("変数要求エラー: {}", e);
                    }
                }
                GdbEvent::Running => {
                    self.status_message = "実行中...".to_string();
                }
                GdbEvent::VariablesUpdated(vars) => {
                    // 前の変数を保存してから新しい変数で更新する
                    self.prev_variables = std::mem::take(&mut self.variables);
                    self.variables = vars;
                    // スクロール位置が範囲外になった場合はクランプする
                    let max_scroll = self.variables.len().saturating_sub(1);
                    if self.var_scroll > max_scroll {
                        self.var_scroll = max_scroll;
                    }
                }
                GdbEvent::ProgramOutput(text) => {
                    for line in text.split('\n') {
                        if self.console_lines.len() >= 500 {
                            self.console_lines.remove(0);
                        }
                        self.console_lines.push(line.to_string());
                    }
                }
                GdbEvent::Error(msg) => {
                    self.status_message = format!("GDB エラー: {}", msg);
                }
            }
        }
    }

    /// -exec-next（ステップオーバー）を GDB に送信する
    fn send_next(&mut self) {
        let Some(gdb) = &self.gdb else { return };
        if let Err(e) = gdb.next() {
            tracing::error!("next 送信エラー: {}", e);
            self.status_message = format!("エラー: {}", e);
        }
    }

    /// -exec-continue（実行継続）を GDB に送信する
    fn send_continue(&mut self) {
        let Some(gdb) = &self.gdb else { return };
        if let Err(e) = gdb.continue_exec() {
            tracing::error!("continue 送信エラー: {}", e);
            self.status_message = format!("エラー: {}", e);
        }
    }

    fn toggle_focus(&mut self) {
        self.focused_panel = match self.focused_panel {
            Panel::Source => Panel::Vars,
            Panel::Vars => Panel::Console,
            Panel::Console => Panel::Source,
        };
    }

    fn scroll_up(&mut self) {
        if self.focused_panel == Panel::Vars {
            self.var_scroll = self.var_scroll.saturating_sub(1);
        }
    }

    fn scroll_down(&mut self) {
        if self.focused_panel == Panel::Vars {
            let max_scroll = self.variables.len().saturating_sub(1);
            if self.var_scroll < max_scroll {
                self.var_scroll += 1;
            }
        }
    }
}
