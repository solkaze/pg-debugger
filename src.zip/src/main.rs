use anyhow::Result;
use crossterm::{
    event::{self, Event, KeyCode, KeyModifiers},
    execute,
    terminal::{disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen},
};
use ratatui::{backend::CrosstermBackend, Terminal};
use std::io;

mod app;
mod debugger;
mod ui;

use app::App;

#[tokio::main]
async fn main() -> Result<()> {
    // ログはファイルに書き出す（TUI と stdout が競合しないよう）
    let log_file = std::fs::File::create("debug.log")?;
    tracing_subscriber::fmt().with_writer(log_file).init();

    // コマンドライン引数から実行ファイルパスを取得
    let args: Vec<String> = std::env::args().collect();
    let executable = args.get(1).map(|s| s.as_str());

    enable_raw_mode()?;
    let mut stdout = io::stdout();
    execute!(stdout, EnterAlternateScreen)?;
    let backend = CrosstermBackend::new(stdout);
    let mut terminal = Terminal::new(backend)?;

    let result = run_app(&mut terminal, executable).await;

    disable_raw_mode()?;
    execute!(terminal.backend_mut(), LeaveAlternateScreen)?;
    terminal.show_cursor()?;

    result
}

async fn run_app(
    terminal: &mut Terminal<CrosstermBackend<io::Stdout>>,
    executable: Option<&str>,
) -> Result<()> {
    let mut app = App::new(executable).await?;

    loop {
        // GDB からのイベントを処理してから描画する
        app.poll_gdb_events();

        terminal.draw(|f| ui::render(f, &app))?;

        if event::poll(std::time::Duration::from_millis(16))? {
            if let Event::Key(key) = event::read()? {
                match key.code {
                    KeyCode::Char('q') => break,
                    KeyCode::Char('c') if key.modifiers.contains(KeyModifiers::CONTROL) => break,
                    _ => app.handle_key(key),
                }
            }
        }
    }

    Ok(())
}
